#include "../cliprdr.h"

void xf_cliprdr_init(CliprdrClientContext* cliprdr)
{
    (void)cliprdr;
}

void xf_cliprdr_uninit( CliprdrClientContext* cliprdr)
{
    (void)cliprdr;
}
