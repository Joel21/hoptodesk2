#!/usr/bin/env bash
cargo build --release --target x86_64-apple-ios --features flutter --lib
